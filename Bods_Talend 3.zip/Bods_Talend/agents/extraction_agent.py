# agents/extraction_agent.py
import os
import requests
from pathlib import Path
import openai
from dotenv import load_dotenv
from tools.bods_parser import parse_bods_script
from tools.talend_converter import convert_extraction_to_talend

load_dotenv()

# Load the prompt from file
EXTRACTION_PROMPT = Path("prompts/extraction_prompt.txt").read_text()

GPT_AZURE_KEY = os.getenv("GPT_AZURE_KEY")
GPT_AZURE_ENDPOINT = os.getenv("GPT_AZURE_ENDPOINT")
GPT_AZURE_DEPLOYMENT = os.getenv("GPT_AZURE_DEPLOYMENT")
GPT_AZURE_API_VERSION = os.getenv("GPT_AZURE_API_VERSION", "2024-12-01-preview")

# Azure OpenAI Model Wrapper
class AzureOpenAIModel:
    def __init__(self):
        self.api_url = (
            f"{GPT_AZURE_ENDPOINT}openai/deployments/"
            f"{GPT_AZURE_DEPLOYMENT}/chat/completions"
            f"?api-version={GPT_AZURE_API_VERSION}"
        )
        self.headers = {
            "Content-Type": "application/json",
            "api-key": GPT_AZURE_KEY,
        }

    def __call__(self, prompt):
        body = {
            "messages": [
                    {"role": "system", "content": "You are an expert in ETL migration from BODS to Talend."},
                    {"role": "user", "content": prompt}
                ],
            "temperature":0.3,
            "max_tokens": 1500
        }
        try:
            response = requests.post(self.api_url, headers=self.headers, json=body)
            response.raise_for_status()
            result = response.json()
            return result["choices"][0]["message"]["content"].strip()
        except requests.exceptions.RequestException as e:
            return f"Error communicating with Azure OpenAI: {str(e)}"

# Extraction Agent using Azure OpenAI
class ExtractionAgent:
    def __init__(self):
        self.model = AzureOpenAIModel()

    def run(self, chunk):
        parsed = parse_bods_script(chunk)
        script_block = parsed.get("script_block", "")
        prompt = EXTRACTION_PROMPT.replace("<<BODS_CHUNK>>", script_block)
        logic_output = self.model(prompt)
        # talend_output = convert_extraction_to_talend(logic_output)
        return logic_output
