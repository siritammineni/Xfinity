String L_ATTP_REPORT = "EXTRACTION_REPORT_WM_MIB_ATTP_" + 
                       ("SG".equals(context.WAVE) ? "RSTO" : context.WAVE) + 
                       "_" + TalendDate.formatDate("yyyyMMdd", TalendDate.getCurrentDate()) + ".txt";

// Talend Job Configuration
// Job Name: MRG_FULL_VMAP_SOURCE_COUNTRY

// Job-level settings
// Execution Mode: Default (Standard)
globalMap.put("EXECUTION_MODE", "Standard");

// Audit and Tracing
globalMap.put("ENABLE_LOGGING", true);
globalMap.put("TRACE_LEVEL", "DEBUG");

// Talend Job Structure
// Subjobs and Triggers
// Subjob 1: Input File
tFileInputDelimited_1.setFileName("SOURCE_COUNTRY.csv");
tFileInputDelimited_1.setHeader(1);
tFileInputDelimited_1.setFieldSeparator(",");
tFileInputDelimited_1.setRowSeparator("\n");

// Subjob 2: Mapping
tMap_1.setInput(tFileInputDelimited_1);
tMap_1.setOutput("MappedData");

// Subjob 3: Output File
tFileOutputDelimited_1.setFileName("OUTPUT_COUNTRY.csv");
tFileOutputDelimited_1.setFieldSeparator(",");
tFileOutputDelimited_1.setRowSeparator("\n");
tFileOutputDelimited_1.setInput(tMap_1.getOutput("MappedData"));

// Execution Trigger
tFileInputDelimited_1.onSubjobOk(tMap_1);
tMap_1.onSubjobOk(tFileOutputDelimited_1);