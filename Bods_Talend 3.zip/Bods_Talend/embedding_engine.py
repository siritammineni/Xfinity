import os
import json
import faiss
import numpy as np
import requests
from dotenv import load_dotenv
 
load_dotenv(".env")
 
class Embedding:
    def __init__(self, index_dir="faiss_indexes"):
        self.index_dir = index_dir
        os.makedirs(self.index_dir, exist_ok=True)
        self.api_url = os.getenv("EMBEDDING_AZURE_URL")
        self.api_key = os.getenv("EMBEDDING_AZURE_KEY")
 
    def store_vectors(self, repo_name, chunks):
        vectors = self.embed_chunks(chunks)
        index_path = os.path.join(self.index_dir, f"{repo_name}.index")
        dimension = vectors.shape[1]
        index = faiss.IndexHNSWFlat(dimension, 32)
        index.add(vectors)
        faiss.write_index(index, index_path)
 
    def embed_chunks(self, chunks):
        headers = {
            "Content-Type": "application/json",
            "api-key": self.api_key
        }
 
        data = {
            "input": chunks
        }
 
        response = requests.post(self.api_url, headers=headers, data=json.dumps(data))
        response.raise_for_status()
        result = response.json()
        embeddings = [item['embedding'] for item in result['data']]
        return np.array(embeddings, dtype=np.float32)