import re
from langchain.schema import AIMessage  # adjust if needed

def parse(ai_message_str: str) -> str:
    """
    Parse an AI message string containing multiple code blocks like ```java ... ```
    and return a single cleaned-up code output with all backticks and language markers removed.
    """
    cleaned_response = ai_message_str.strip()

    # Find all code blocks wrapped in triple backticks using regex
    # This captures content inside ```...```, optionally starting with a language identifier like ```java
    code_blocks = re.findall(r"```(?:\w+)?\s*([\s\S]*?)```", cleaned_response)

    # Join all the cleaned code blocks with spacing
    final_code = "\n\n".join(block.strip() for block in code_blocks if block.strip())

    return final_code
# from langchain.schema import AIMessage  # or whatever your actual import is

# def parse(ai_message_str : str) -> str:
#     """Parse the AI message and strip code block markers (```lang ... ```)"""
#     cleaned_response = ai_message_str.strip()

#     # Remove code block markers like ```java, ```python, etc.
#     if cleaned_response.startswith("```"):
#         # Find the first newline after the language identifier
#         first_newline_index = cleaned_response.find("\n")
#         if first_newline_index != -1:
#             cleaned_response = cleaned_response[first_newline_index + 1:]

#     if cleaned_response.endswith("```"):
#         cleaned_response = cleaned_response[:-3]

#     cleaned_response = cleaned_response.strip()
    
#     return cleaned_response
