from langgraph.graph import StateGraph, END
from responder_engine import ResponderEngine
from typing import TypedDict
import time


class CompareState(TypedDict):
    original_code : str
    converted_code : str
    comparison: str

graph = StateGraph(CompareState)
engine = ResponderEngine()

def functionality_comparison_agent(state):
    original_code = state["original_code"]
    converted_code = state["converted_code"]

    comparison = engine.run_functionality_comparison(original_code, converted_code)
    return{
            "original_code": original_code,
            "converted_code": converted_code,
            "comparison" : comparison
        }

graph.add_node("FunctionalityComparison",functionality_comparison_agent)
graph.set_entry_point("FunctionalityComparison")
graph.add_edge("FunctionalityComparison", END)

app = graph.compile()
