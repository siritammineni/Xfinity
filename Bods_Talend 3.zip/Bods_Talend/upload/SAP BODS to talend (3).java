// Talend Job Script in Java

import java.text.SimpleDateFormat;
import java.util.Date;

public class JB_MEDIUM_SCR {

    public static void main(String[] args) {
        // Initialize Job
        String jobName = "JB_MEDIUM_SCR";
        String jobType = "batch";
        String jobMode = "Multi-Process";
        boolean jobEnableAssemblers = true;
        boolean jobEnableAudit = true;
        boolean jobEnableDataQuality = true;
        boolean jobTraceDataflow = true;
        boolean jobTraceSession = true;
        boolean jobTraceWorkflow = true;
        boolean jobUseStatistics = true;
        String localeCodepage = "<default>";
        String localeLanguage = "<default>";
        String localeTerritory = "<default>";

        // Print start message
        System.out.println("----**** Your Script has started execution *****------");

        // Get current date
        Date currentDate = new Date();

        // Print today's date
        SimpleDateFormat dayFormat = new SimpleDateFormat("dd");
        String dayPart = dayFormat.format(currentDate);
        System.out.println("TODAY'S DATE : " + dayPart);

        // Print current month
        SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
        String monthPart = monthFormat.format(currentDate);
        System.out.println("CURRENT MONTH :" + monthPart);

        // Print current year
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        String yearPart = yearFormat.format(currentDate);
        System.out.println("CURRENT YEAR :" + yearPart);

        // Print end message
        System.out.println("----**** Your Script has executed successfully *****------");
    }
}