# tools/talend_converter.py

def convert_extraction_to_talend(logic: str) -> str:
    # Simplified example: map generic read logic to Talend component
    if "read_table" in logic or "select" in logic.lower():
        return "Use: tDBInput\nConfigure DB connection and SQL query."
    elif "tFileInput" in logic:
        return "Use: tFileInputDelimited\nConfigure path, delimiter, and schema."
    else:
        return "Extraction pattern not recognized."

def convert_transformation_to_talend(logic: str) -> str:
    if "join" in logic.lower():
        return "Use: tJoin or tMap with multiple inputs."
    elif "filter" in logic.lower():
        return "Use: tFilterRow."
    elif "case" in logic.lower() or "if" in logic.lower():
        return "Use: tMap with expression filters."
    else:
        return "Use: tMap for transformation logic."

def convert_loading_to_talend(logic: str) -> str:
    if "insert" in logic.lower() or "write_table" in logic:
        return "Use: tDBOutput.\nConfigure target table, mappings, and write mode."
    elif "tFileOutput" in logic:
        return "Use: tFileOutputDelimited\nSet file path and schema."
    else:
        return "Loading pattern not recognized."

def convert_job_config_to_talend(parameters: dict) -> str:
    return f"""Talend Job Configuration Suggestion:
- Job Name: {parameters.get('job_name', 'Unknown')}
- Audit Enabled: {parameters.get('job_enable_audit', 'no')}
- Trace Workflow: {parameters.get('job_trace_workflow', 'no')}
- Execution Mode: {parameters.get('job_mode', 'Single-Process')}
"""
