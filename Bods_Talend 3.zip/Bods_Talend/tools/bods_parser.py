import re

def extract_job_name(script: str) -> str:
    match = re.search(r"CREATE SESSION\s+(\w+)", script)
    return match.group(1).strip() if match else "Unknown_Job"

def extract_script_block(script: str) -> str:
    match = re.search(r"BEGIN_SCRIPT(.*?)END", script, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else ""

def extract_parameters(script: str) -> dict:
    match = re.search(r"SET\s*\((.*?)\)", script, re.DOTALL | re.IGNORECASE)
    param_block = match.group(1).strip() if match else ""
    params = {}
    for pair in re.findall(r'"([^"]+)"\s*=\s*\'([^\']*)\'', param_block):
        key, value = pair
        params[key.strip()] = value.strip()
    return params

def extract_all_comments(script: str) -> list:
    return re.findall(r'AlGUIComment\s*\((.*?)\)', script, re.DOTALL)

def split_script_logic(script_block: str) -> dict:
    lines = script_block.splitlines()
    extraction = []
    transformation = []
    loading = []

    for line in lines:
        clean_line = line.strip().lower()

        # Categorize based on common keywords
        if any(kw in clean_line for kw in ['select', 'from', 'read_table']):
            extraction.append(line)
        elif any(kw in clean_line for kw in ['join', 'case', 'if', 'when', 'filter', 'expression']):
            transformation.append(line)
        elif any(kw in clean_line for kw in ['insert', 'into', 'write_table', 'tfileoutput', 'toutput']):
            loading.append(line)
        else:
            # If it's not clearly one type, assume it may be shared
            pass  # Or: optionally add to `transformation`

    return {
        "extraction_logic": "\n".join(extraction).strip(),
        "transformation_logic": "\n".join(transformation).strip(),
        "loading_logic": "\n".join(loading).strip()
    }

def parse_bods_script(script: str) -> dict:
    job_name = extract_job_name(script)
    script_block = extract_script_block(script)
    parameters = extract_parameters(script)
    comments = extract_all_comments(script)
    logic_split = split_script_logic(script_block)

    return {
        "job_name": job_name,
        "script_block": script_block,
        "parameters": parameters,
        "comments": comments,
        **logic_split  # Adds extraction_logic, transformation_logic, loading_logic
    }
