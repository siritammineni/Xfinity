# chunking_tool.py

import re

def chunk_bods_script(script: str) -> dict:
    # Initialize chunks
    chunks = {
        "extraction": "",
        "transformation": "",
        "loading": "",
        "job": ""
    }

    # Normalize whitespace and newlines
    script = script.replace('\r', '')

    # Extract the BEGIN_SCRIPT block as transformation logic
    transformation_match = re.search(r"BEGIN_SCRIPT(.*?)END", script, re.DOTALL | re.IGNORECASE)
    if transformation_match:
        chunks["transformation"] = transformation_match.group(1).strip()

    # Attempt to extract job configuration metadata (SET block)
    job_match = re.search(r"SET\s*\((.*?)\)", script, re.DOTALL | re.IGNORECASE)
    if job_match:
        chunks["job"] = job_match.group(1).strip()

    # Extraction logic: detect any references to file/db read (you can expand patterns)
    extraction_keywords = ["tFileInput", "read_table", "sql()", "source_file", "select "]
    extraction_lines = [line for line in script.splitlines() if any(k in line.lower() for k in extraction_keywords)]
    chunks["extraction"] = "\n".join(extraction_lines)

    # Loading logic: detect any references to output targets
    loading_keywords = ["tFileOutput", "write_table", "insert ", "target_table"]
    loading_lines = [line for line in script.splitlines() if any(k in line.lower() for k in loading_keywords)]
    chunks["loading"] = "\n".join(loading_lines)

    return chunks
