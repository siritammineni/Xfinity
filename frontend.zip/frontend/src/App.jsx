import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import IntroPage from './pages/IntroPage';
import IndexPage from './pages/indexpage';
import ReviewPage from './pages/reviewpage';
import LoginSignup from './pages/LoginSignup';
import ConfigurationPage from './pages/ConfigurationPage';
import ComparisonPage from './pages/ComparisonPage';
import ProfilePage from './pages/ProfilePage';
import EditProfilePage from './pages/EditProfilePage';
import HistoryPage from './pages/HistoryPage';
import DownloadPage from './pages/DownloadPage';
import HelpPage from './pages/HelpPage';
import './App.css';
import ConverterPage from './pages/ConverterPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<IntroPage />} />
        <Route path="/index" element={<IndexPage />} />
        <Route path="/review" element={<ReviewPage />} />
        <Route path="/signup" element={<LoginSignup />} />
        <Route path="/config" element={<ConfigurationPage />} />
        <Route path="/comparison" element={<ComparisonPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/edit-profile" element={<EditProfilePage />} />
        <Route path="/history" element={<HistoryPage />} />
        <Route path="/downloads" element={<DownloadPage />} />
        <Route path="/help" element={<HelpPage />} />
        <Route path="/converter" element={<ConverterPage />} />
      </Routes>
    </Router>
  );
}

export default App;
