import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faMoon, faSun, faSignOutAlt, faGear } from '@fortawesome/free-solid-svg-icons';
import { faGithub } from '@fortawesome/free-brands-svg-icons';

const ComparisonPage = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [data, setData] = useState({
    functional_table: '',
    code_quality: '',
    suggestions: '',
  });

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeUser, setActiveUser] = useState(null);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const sidebarRef = useRef(null);
  const hamburgerRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:5000/compare")
      .then(res => res.json())
      .then(setData)
      .catch(err => console.error('Error fetching comparison report:', err));
  }, []);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("activeUser"));
    if (storedUser) setActiveUser(storedUser);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        sidebarRef.current &&
        !sidebarRef.current.contains(event.target) &&
        !hamburgerRef.current.contains(event.target)
      ) {
        setSidebarOpen(false);
      }
      if (!event.target.closest('.top-right-profile')) {
        setShowProfileMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleDarkMode = () => {
    document.body.classList.toggle("dark-mode");
    setDarkMode(!darkMode);
  };

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  const toggleProfileMenu = () => setShowProfileMenu(prev => !prev);

  const handleLogout = () => {
    localStorage.removeItem("activeUser");
    navigate('/');
  }

  const downloadReport = () => {
    axios({
      url: "http://localhost:5000/download_comparison_report",
      method: "GET",
      responseType: "blob",
    })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "CodeSphere_Comparison_Report.docx");
        document.body.appendChild(link);
        link.click();
        link.remove();
      })
      .catch((err) => {
        alert("Download failed: " + err.message);
      });
  };

  return (
    <div className="compare-background">
      {/* Logo */}
      <div className="logo-group">
        <img src="/images/logo1.png" alt="Logo" className="logo" />
        <span className="logo-text">CodeSphere</span>
      </div>

      {/* Hamburger Icon */}
      <div
        ref={hamburgerRef}
        className={`hamburger ${sidebarOpen ? 'active' : ''}`}
        onClick={toggleSidebar}
      >
        <div></div>
        <div></div>
        <div></div>
      </div>

      {/* Sidebar */}
      {sidebarOpen && (
        <div ref={sidebarRef} className="sidebar"><br />
          <a href="/index" className='sidebar-item'><FontAwesomeIcon icon={faHome} /> Home</a>
          <button onClick={toggleDarkMode} className='sidebar-item1'>
            <FontAwesomeIcon icon={darkMode ? faSun : faMoon} /> DarkMode
          </button>
          <a href="https://github.com/" target="_blank" rel="noopener noreferrer" className='sidebar-item'>
            <FontAwesomeIcon icon={faGithub} /> GitHub
          </a>
          <a href='/config' className='sidebar-item'>
            <FontAwesomeIcon icon={faGear} /> Configuration Page
          </a>
        </div>
      )}

      {/* User Profile */}
      {activeUser && (
        <div className='top-right-profile'>
          <button className="user-profile-button" onClick={toggleProfileMenu}>
            <img src="/images/log4.png" alt="User" className="user-avatar" />
            <span className="user-name">{activeUser.username}</span>
          </button>
          {showProfileMenu && (
            <div className="profile-dropdown">
              <ul>
                <li onClick={() => navigate('/profile')}>👤 View Profile</li>
                <li onClick={() => navigate('/edit-profile')}>✏️ Edit Profile</li>
                <li onClick={() => navigate('/history')}>🕒 My Reviews</li>
                <li onClick={() => navigate('/downloads')}>📥 Download Reports</li>
                <li onClick={() => navigate('/help')}>❓ Help & Support</li>
                <li onClick={() => handleLogout()}>🚪 Logout</li>
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Main Content */}
      <main className="review-container">
        <h1 className="page-title">Functionality Migration Report</h1>

        <section className="section">
          <h2>Functional Comparison Table</h2>
          <div className="box" dangerouslySetInnerHTML={{ __html: data.functional_table }} />
        </section>

        <section className="section">
          <h2>Code Quality Assessment</h2>
          <div className="box" dangerouslySetInnerHTML={{ __html: data.code_quality }} />
        </section>

        <section className="section">
          <h2>Enhancements / Suggestions</h2>
          <div className="box" dangerouslySetInnerHTML={{ __html: data.suggestions }} />
        </section>

        <section className="section">
          <h2>Revised Code</h2>
          <div className="box" dangerouslySetInnerHTML={{ __html: data.revised_code }} />
        </section>
        <button className="download-button" onClick={downloadReport}>
          ⬇️ Download Migration Report
        </button>
      </main>
    </div>
  );
};

export default ComparisonPage;
