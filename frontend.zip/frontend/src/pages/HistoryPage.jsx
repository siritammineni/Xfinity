// import React from 'react';
// import '../App.css';

// const HistoryPage = () => {
//   const githubURL = sessionStorage.getItem('githubURL');
//   const uploadedFiles = JSON.parse(sessionStorage.getItem('uploadedFiles') || '[]');

//   return (
//     <div className="history-page">
//       <h2>Review History</h2>
//       {githubURL && <p><strong>GitHub URL:</strong> {githubURL}</p>}
//       {uploadedFiles.length > 0 && (
//         <>
//           <strong>Uploaded Files:</strong>
//           <ul>
//             {uploadedFiles.map((file, index) => (
//               <li key={index}>{file}</li>
//             ))}
//           </ul>
//         </>
//       )}
//     </div>
//   );
// };

// export default HistoryPage;

import React, { useEffect, useState } from 'react';
import '../App.css';

const HistoryPage = () => {
  const [uploads, setUploads] = useState([]);

  useEffect(() => {
    // Retrieve upload history from localStorage
    const history = JSON.parse(localStorage.getItem('uploadHistory')) || [];
    setUploads(history);
  }, []);

  return (
    <div className="history-page-container">
      <h2>📂 Uploaded File History</h2>
      {uploads.length === 0 ? (
        <p>No uploaded files found. Start by analyzing a repo or file.</p>
      ) : (
        <ul className="history-list">
          {uploads.map((item, index) => (
            <li key={index}>
              <strong>{item.type}:</strong> {item.detail} <br />
              <small>{item.timestamp}</small>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default HistoryPage;
