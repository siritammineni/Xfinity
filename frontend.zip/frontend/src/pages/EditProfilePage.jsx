import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';

const EditProfilePage = () => {
  const navigate = useNavigate();
  const existingUser = JSON.parse(localStorage.getItem('activeUser'));

  const [username, setUsername] = useState(existingUser?.username || '');
  const [email, setEmail] = useState(existingUser?.email || '');
  const [gender, setGender] = useState(existingUser?.gender || 'male');

  const handleSave = () => {
    const updatedUser = { username, email, gender };
    localStorage.setItem('activeUser', JSON.stringify(updatedUser));
    navigate('/profile');
  };

  return (
    <div className="edit-profile-container">
      <h2>Edit Profile</h2>
      <label>Name: <input value={username} onChange={(e) => setUsername(e.target.value)} /></label><br />
      <label>Email: <input value={email} onChange={(e) => setEmail(e.target.value)} /></label><br />
      <label>Gender: 
        <select value={gender} onChange={(e) => setGender(e.target.value)}>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </label><br />
      <button onClick={handleSave}>Save</button>
    </div>
  );
};

export default EditProfilePage;
