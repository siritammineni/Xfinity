import React from 'react';
import '../App.css';

const HelpPage = () => {
  return (
    <div>
      <h2>Help & Support</h2>
      <p>📧 Email: support@CodeSphere.com</p>
      {/* <p>📄 Documentation: <a href="https://yourdoc.com" target="_blank">View Guide</a></p> */}
    </div>
  );
};

export default HelpPage;