import React from 'react';
import '../App.css';

const ProfilePage = () => {
  const user = JSON.parse(localStorage.getItem('activeUser'));

  if (!user) return <p>User not logged in</p>;

  return (
    <div className="profile-container">
      <h2>User Profile</h2>
      <img
        src="/images/log3.png"
        alt="avatar"
        className="profile-avatar"
      />
      <p><strong>Name:</strong> {user.username}</p>
      <p><strong>Email:</strong> {user.email}</p>
    </div>
  );
};

export default ProfilePage;