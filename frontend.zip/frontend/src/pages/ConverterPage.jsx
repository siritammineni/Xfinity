import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faMoon, faSun, faFileCode, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';

const ConverterPage = () => {
  const [convertedCode, setConvertedCode] = useState('');
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [targetLanguage, setTargetLanguage] = useState('');
  const [model, setModel] = useState('');
  const [BODSFiles, setBODSFiles] = useState(null);
  const [XMLFile, setXMLFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState({
    input: 'pending',
    pseudo: 'pending',
    conversion: 'pending',
    output: 'pending',
  });
  const [showConvertedOutput, setShowConvertedOutput] = useState(false);

  const navigate = useNavigate();
  const sidebarRef = useRef(null);
  const hamburgerRef = useRef(null);

  
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        sidebarRef.current &&
        !sidebarRef.current.contains(event.target) &&
        !hamburgerRef.current.contains(event.target)
      ) {
        setSidebarOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  const toggleDarkMode = () => {
    document.body.classList.toggle("dark-mode");
    setDarkMode(!darkMode);
  };

  const handleBodsFileChange = (e) => {
    const file = e.target.files[0];
    if (file) setBODSFiles(file);
  };

  const handleXmlFileChange = (e) => {
    const file = e.target.files[0];
    if (file) setXMLFile(file);
  };

  const canConvert = BODSFiles && XMLFile && targetLanguage && model;

  useEffect(() => {
    if (BODSFiles && XMLFile) {
      setStatus((s) => ({ ...s, input: 'success' }));
    } else {
      setStatus((s) => ({ ...s, input: 'pending' }));
    }
  }, [BODSFiles, XMLFile]);

  const handleConvert = async () => {
    if (!canConvert) {
      alert("Please upload both files and select language & LLM.");
      return;
    }

    setStatus({ input: 'success', pseudo: 'running', conversion: 'pending', output: 'pending' });
    setConvertedCode('');
    setLoading(true);

    try {
      // Simulate pseudo agent
      await new Promise((resolve) => setTimeout(resolve, 4000));
      setStatus((s) => ({ ...s, pseudo: 'success', conversion: 'running', output: 'pending' }));

      // Simulate conversion agent
      const formData = new FormData();
      formData.append('bods_file', BODSFiles);
      formData.append('xml_file', XMLFile);
      formData.append('target_language', targetLanguage);
      formData.append('model', model);

      const response = await axios.post('http://127.0.0.1:5000/convert', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      const { converted_code, converted_file } = response.data;
      setConvertedCode(converted_code);
      setStatus((s) => ({ ...s, conversion: 'success', output: 'running'}));

      // Auto download
      const downloadUrl = `http://127.0.0.1:5000/download/${converted_file}`;
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', converted_file);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      alert('Conversion Successful!');
    } catch (error) {
      console.error(error);
      alert('Conversion failed.');
      setStatus((s) => ({ ...s, pseudo: 'pending', conversion: 'pending' }));
    } finally {
      setLoading(false);
    }

    setStatus((s) => ({ ...s, output: 'success'}));
  };

  const renderStatus = (label, state) => (
    <div className={`status-step ${state}`}>
      <div className="dot" />
      <div className="label">{label}</div>
      <div className="text">
        {state === 'success' ? 'Completed' : state === 'running' ? 'In Progress' : 'Pending'}
      </div>
    </div>
  );

  return (
    <div className='converter-body'>
      <div className="converter-wrapper">
        <div className="logo-group">
          <img src="/images/logo1.png" alt="Logo" className="logo" />
          <span className="logo-text">CodeSphere</span>
        </div>

        <div ref={hamburgerRef} className={`hamburger ${sidebarOpen ? 'active' : ''}`} onClick={toggleSidebar}>
          <div></div><div></div><div></div>
        </div>

        {sidebarOpen && (
          <div ref={sidebarRef} className="sidebar"><br />
            <a href="/" className='sidebar-item'><FontAwesomeIcon icon={faHome} /> Home</a>
            <button onClick={toggleDarkMode} className='sidebar-item1'><FontAwesomeIcon icon={darkMode ? faSun : faMoon} /> DarkMode</button>
            <a href="/index" className='sidebar-item'><FontAwesomeIcon icon={faFileCode} /> Analyse</a>
            <a href="/" className='sidebar-item'><FontAwesomeIcon icon={faSignOutAlt} /> Logout</a>
          </div>
        )}

        <div className="header">
          <h1>Code Converter</h1>
        </div>

        <div className="control-panel">
          <div className="input-row">
            <div className="input-group1">
              <label htmlFor="bods-upload">Upload BODS File:</label>
              <input type="file" id="bods-upload" accept=".atl" onChange={handleBodsFileChange} />
            </div>

            <div className="input-group2">
              <label htmlFor="xml-upload">Upload XML File:</label>
              <input type="file" id="xml-upload" accept=".xml" onChange={handleXmlFileChange} />
            </div>
          </div>

          <div className="input-row">
            <div className="input-group3">
              <label>Language:</label>
              <select className="select" onChange={(e) => setTargetLanguage(e.target.value)} value={targetLanguage}>
                <option className="select-option" value="">Select Language</option>
                <option className="select-option" value="pyspark">PySpark</option>
                <option className="select-option" value="sql">SQL</option>
                <option className="select-option" value="scala">Scala</option>
                <option className="select-option" value="java">Java</option>
              </select>
            </div>

            <div className="input-group4">
              <label>LLM:</label>
              <select className="select" onChange={(e) => setModel(e.target.value)} value={model}>
                <option className="select-option" value="">Select LLM</option>
                <option className="select-option" value="gpt-4o">GPT-4o</option>
                <option className="select-option" value="mistral">Mistral</option>
                <option className="select-option" value="llama">LLaMA</option>
              </select>
            </div>
          </div>
        </div>

        <button className="convert-button" onClick={handleConvert} disabled={!canConvert || loading}>
          {loading ? 'Converting...' : 'Convert'}
        </button>

        <div className="main-content">
          <div className="glass-card code-box">
            <h2>Converted Code</h2>
            <pre>{convertedCode || '// Upload file and wait for conversion...'}</pre>
          </div>

          <div className="glass-card tracker">
            <h2>Conversion Progress</h2>
            <div className="status-timeline">
              {renderStatus('Input File Uploaded', status.input)}
              {renderStatus('Pseudo Code Agent', status.pseudo)}
              {renderStatus('Conversion Agent', status.conversion)}
              {renderStatus('Output Converted Code', status.output)}
            </div>
          </div>
        </div>
      </div>
      <button
                  onClick={() => {
                    const blob = new Blob([convertedCode], { type: 'text/plain' });
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = 'converted_code.txt';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                  }}
                  className="download-btn"
                >
                  ⬇️ Download Converted Code
                </button>
    </div>
  );
};

export default ConverterPage;
