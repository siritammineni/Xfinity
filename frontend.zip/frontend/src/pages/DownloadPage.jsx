import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../App.css';

const DownloadPage = () => {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('downloadHistory')) || [];
    setHistory(saved);
  }, []);

  const downloadFile = (type) => {
    let endpoint = '';
    let filename = '';

    if (type === 'review') {
      endpoint = 'http://localhost:5000/download_docx';
      filename = 'CodeSphere_Review_Report.docx';
    } else if (type === 'comparison') {
      endpoint = 'http://localhost:5000/download_comparison_docx';
      filename = 'CodeSphere_Comparison_Report.docx';
    }

    axios({
      url: endpoint,
      method: 'GET',
      responseType: 'blob',
    })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        link.remove();

        // ✅ Track download
        const previous = JSON.parse(localStorage.getItem('downloadHistory')) || [];
        const newEntry = {
          filename,
          timestamp: new Date().toLocaleString()
        };
        const updated = [newEntry, ...previous];
        localStorage.setItem('downloadHistory', JSON.stringify(updated));
        setHistory(updated); // update state
      })
      .catch((err) => {
        console.error('Download failed:', err);
        alert('Failed to download report.');
      });
  };

  return (
    <div className="download-page-container">
      <h2>Download Your Reports</h2>
      <p>You can download your recent reports below:</p>

      <div className="download-buttons">
        <button className="download-button" onClick={() => downloadFile('review')}>
          ⬇️ Download Review Report
        </button>
        <button className="download-button" onClick={() => downloadFile('comparison')}>
          ⬇️ Download Comparison Report
        </button>
      </div>

      {history.length > 0 ? (
        <div className="download-history">
          <h3>📜 Download History</h3>
          <ul>
            {history.map((item, index) => (
              <li key={index}>
                <strong>{item.filename}</strong> — <em>{item.timestamp}</em>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <p>No reports downloaded yet.</p>
      )}
    </div>
  );
};

export default DownloadPage;
