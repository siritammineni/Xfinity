import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faMoon, faSun, faGear } from '@fortawesome/free-solid-svg-icons';
import { faGithub } from '@fortawesome/free-brands-svg-icons';

const ReviewPage = () => {
  const navigate = useNavigate();
  const [reviewSections, setReviewSections] = useState({});
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeUser, setActiveUser] = useState(null);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const sidebarRef = useRef(null);
  const hamburgerRef = useRef(null);

  useEffect(() => {
    axios.get("http://localhost:5000/review2")
      .then(res => setReviewSections(res.data))
      .catch(err => console.error("Error fetching review:", err));
  }, []);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("activeUser"));
    if (user) setActiveUser(user);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        sidebarRef.current &&
        !sidebarRef.current.contains(event.target) &&
        !hamburgerRef.current.contains(event.target)
      ) {
        setSidebarOpen(false);
      }
      if (!event.target.closest('.top-right-profile')) {
        setShowProfileMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  const toggleDarkMode = () => {
    document.body.classList.toggle("dark-mode");
    setDarkMode(!darkMode);
  };

  const handleLogout = () => {
    localStorage.removeItem("activeUser");
    navigate('/');
  }

  return (
    <div className="review-background">
      <div className="logo-group">
        <img src="/images/logo1.png" alt="Logo" className="logo" />
        <span className="logo-text">CodeSphere</span>
      </div>

      {/* Hamburger Icon */}
      <div ref={hamburgerRef}
        className={`hamburger ${sidebarOpen ? 'active' : ''}`}
        onClick={toggleSidebar}>
        <div></div>
        <div></div>
        <div></div>
      </div>

      {sidebarOpen && (
        <div ref={sidebarRef} className="sidebar"><br></br>
          <a href="/index" className='sidebar-item'><FontAwesomeIcon icon={faHome} /> Home</a>
          <button onClick={toggleDarkMode} className='sidebar-item1'>
            <FontAwesomeIcon icon={darkMode ? faSun : faMoon} /> DarkMode
          </button>
          <a href="https://github.com/" className='sidebar-item'><FontAwesomeIcon icon={faGithub} /> GitHub</a>
          <a href='/config' className='sidebar-item'><FontAwesomeIcon icon={faGear} /> Configuration  Page</a>
        </div>
      )}

      {activeUser && (
        <div className='top-right-profile'>
          <button className="user-profile-button" onClick={() => setShowProfileMenu(prev => !prev)}>
            <img src="/images/log4.png" alt="User" className="user-avatar" />
            <span className="user-name">{activeUser.username}</span>
          </button>
          {showProfileMenu && (
            <div className="profile-dropdown">
              <ul>
              <li onClick={() => navigate('/profile')}>👤 View Profile</li>
              <li onClick={() => navigate('/edit-profile')}>✏️ Edit Profile</li>
              <li onClick={() => navigate('/history')}>🕒 My Reviews</li>
              <li onClick={() => navigate('/downloads')}>📥 Download Reports</li>
              <li onClick={() => navigate('/help')}>❓ Help & Support</li>
              <li onClick={() => handleLogout()}>🚪 Logout</li>
              </ul>
            </div>
          )}
        </div>
      )}

      <main className="review-container">
      <h1 className="page-title">Review Report</h1>
        {Object.entries(reviewSections).map(([key, section]) => (
          <section className="section" key={key}>
            <h2>{section.title}</h2>
            <div className="box" dangerouslySetInnerHTML={{ __html: section.body }} />
          </section>
        ))}
        <button className="download-button" onClick={() => window.location.href = "http://localhost:5000/download_docx"}>⬇️ Download Report</button>
      </main>
    </div>
  );
};

export default ReviewPage;
