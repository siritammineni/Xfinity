```java
// Talend Job Script for Mass Vendor Creation

// Import necessary Talend libraries
import java.util.HashMap;
import java.util.Map;
import routines.system.Row;
import routines.system.TalendDataSource;

public class MassVendorCreation {

    public static void main(String[] args) throws Exception {
        // Initialize Talend components
        TalendDataSource dataSource = new TalendDataSource();
        Map<String, String> vendorData = new HashMap<>();

        // Step 1: Connect to SAP Production
        System.out.println("Connecting to SAP Production...");
        dataSource.connect("SAP Production");

        // Step 2: Open transaction XK01
        System.out.println("Opening transaction XK01...");
        dataSource.executeCommand("/nXK01");

        // Step 3: Populate vendor master data
        System.out.println("Populating vendor master data...");
        vendorData.put("RF02K-LIFNR", "100001"); // Vendor Number
        vendorData.put("RF02K-BUKRS", "1000");   // Company Code
        vendorData.put("RF02K-EKORG", "1000");   // Purchasing Organization
        vendorData.put("RF02K-KTOKK", "Z001");   // Account Group

        for (Map.Entry<String, String> entry : vendorData.entrySet()) {
            dataSource.setField(entry.getKey(), entry.getValue());
        }

        // Step 4: Populate additional vendor details
        System.out.println("Populating additional vendor details...");
        vendorData.put("LFA1-NAME1", "Vendor ABC Ltd."); // Vendor Name
        vendorData.put("LFA1-ORT01", "Berlin");          // City
        vendorData.put("LFA1-PSTLZ", "10115");           // Postal Code
        vendorData.put("LFA1-LAND1", "DE");              // Country

        for (Map.Entry<String, String> entry : vendorData.entrySet()) {
            dataSource.setField(entry.getKey(), entry.getValue());
        }

        // Step 5: Save the vendor data
        System.out.println("Saving vendor data...");
        dataSource.save();

        // Disconnect from SAP
        System.out.println("Disconnecting from SAP...");
        dataSource.disconnect();

        System.out.println("Vendor creation completed successfully.");
    }
}
```