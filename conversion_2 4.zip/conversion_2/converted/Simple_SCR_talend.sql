```sql
-- Talend Job Script in SQL

-- Print message indicating the start of the script execution
SELECT '----**** Your Script has started execution *****------' AS StartMessage;

-- Calculate the length of the job name and print it
SELECT 'Length of the job name is: ' || LENGTH('JB_SIMPLE_SCR') AS JobNameLength;

-- Print message indicating successful execution of the script
SELECT '----**** Your Script has executed successfully *****------' AS EndMessage;
```