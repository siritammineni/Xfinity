import java.util.Locale;

public class JB_SIMPLE_SCR {

    public static void main(String[] args) {
        // Initialize job attributes
        String repositoryVersion = "14.3.3.0000";
        String productVersion = "14.3.3.385";
        String jobName = "JB_SIMPLE_SCR";
        boolean jobCheckpointEnabled = false;
        boolean jobCollectStatistics = false;
        boolean jobCollectStatisticsMonitor = false;
        boolean jobCreateDebugPackage = false;
        boolean jobEnableAssemblers = true;
        boolean jobEnableAudit = true;
        boolean jobEnableDataQuality = true;
        boolean jobExportRepo = false;
        boolean jobExportReports = false;
        boolean jobIsRecoverable = false;
        String jobMode = "Multi-Process";
        int jobMonitorSampleRate = 1000;
        int jobMonitorTimerRate = 5;
        boolean jobPrintVersion = false;
        boolean jobTestModeEnabled = false;
        boolean jobTraceDataFlow = true;
        boolean jobTraceSession = true;
        boolean jobTraceWorkflow = true;
        String jobType = "batch";
        boolean jobUseStatistics = true;
        Locale locale = Locale.getDefault();

        // Begin script execution
        System.out.println("----**** Your Script has started execution *****------");

        // Calculate the length of the job name and print it
        int jobNameLength = jobName.length();
        System.out.println("Length of the job name is: " + jobNameLength);

        // End script execution
        System.out.println("----**** Your Script has executed successfully *****------");
    }
}