from pyspark.sql import SparkSession
from pyspark.sql.functions import current_date, date_format

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("JB_MEDIUM_SCR") \
    .getOrCreate()

# Print Start Message
print("----**** Your Script has started execution *****------")

# Print Today's Date
today_date = spark.sql("SELECT date_format(current_date(), 'dd') AS day").collect()[0]['day']
print(f"TODAY'S DATE : {today_date}")

# Print Current Month
current_month = spark.sql("SELECT date_format(current_date(), 'MM') AS month").collect()[0]['month']
print(f"CURRENT MONTH : {current_month}")

# Print Current Year
current_year = spark.sql("SELECT date_format(current_date(), 'yyyy') AS year").collect()[0]['year']
print(f"CURRENT YEAR : {current_year}")

# Print End Message
print("----**** Your Script has executed successfully *****------")

# Stop Spark Session
spark.stop()