```java
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

public class TalendJob {

    public static void main(String[] args) {
        // JB_COMPLEX_SCR Job
        System.out.println("----**** Your Script has started execution *****------");

        LocalDate currentDate = LocalDate.now();

        // Print today's date (day of the month)
        System.out.println("TODAY'S DATE : " + currentDate.getDayOfMonth());

        // Print current month number
        System.out.println("CURRENT MONTH NUMBER :" + currentDate.getMonthValue());

        // Print current year
        System.out.println("CURRENT YEAR :" + currentDate.getYear());

        // Print day in the year
        System.out.println("DAY IN THE YEAR : " + currentDate.getDayOfYear());

        // Print day in the month
        System.out.println("DAY IN THE MONTH : " + currentDate.getDayOfMonth());

        // Print day in the week
        System.out.println("DAY IN THE WEEK : " + currentDate.getDayOfWeek().getValue());

        // Print current month name
        System.out.println("CURRENT MONTH : " + currentDate.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH));

        System.out.println("----**** Your Script has executed successfully *****------");

        // JB_MEDIUM_SCR Job
        System.out.println("----**** Your Script has started execution *****------");

        // Print today's date (day of the month)
        System.out.println("TODAY'S DATE : " + currentDate.getDayOfMonth());

        // Print current month number
        System.out.println("CURRENT MONTH :" + currentDate.getMonthValue());

        // Print current year
        System.out.println("CURRENT YEAR :" + currentDate.getYear());

        System.out.println("----**** Your Script has executed successfully *****------");

        // JB_SIMPLE_SCR Job
        System.out.println("----**** Your Script has started execution *****------");

        // Print length of the job name
        String jobName = "JB_SIMPLE_SCR";
        System.out.println("Length of the job name is: " + jobName.length());

        System.out.println("----**** Your Script has executed successfully *****------");
    }
}
```