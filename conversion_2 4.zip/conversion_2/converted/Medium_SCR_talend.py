```python
from pyspark.sql import SparkSession
from datetime import datetime

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("JB_MEDIUM_SCR") \
    .getOrCreate()

# Logging the start of the script
print("----**** Your Script has started execution *****------")

# Extracting current date details
current_date = datetime.now()
day = current_date.strftime("%d")
month = current_date.strftime("%m")
year = current_date.strftime("%Y")

# Printing the extracted details
print(f"TODAY'S DATE : {day}")
print(f"CURRENT MONTH : {month}")
print(f"CURRENT YEAR : {year}")

# Logging the end of the script
print("----**** Your Script has executed successfully *****------")

# Stop Spark Session
spark.stop()
```