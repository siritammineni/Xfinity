```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_date, date_format, dayofmonth, month, year, dayofyear, dayofweek

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("JB_COMPLEX_SCR") \
    .getOrCreate()

# Print Start Message
print("----**** Your Script has started execution *****------")

# Get Current Date
current_date = spark.sql("SELECT current_date() AS current_date").collect()[0]['current_date']

# Calculate and Print Today's Date
day = spark.sql(f"SELECT dayofmonth('{current_date}') AS day").collect()[0]['day']
print(f"TODAY'S DATE : {day}")

# Calculate and Print Current Month Number
month_number = spark.sql(f"SELECT month('{current_date}') AS month").collect()[0]['month']
print(f"CURRENT MONTH NUMBER : {month_number}")

# Calculate and Print Current Year
current_year = spark.sql(f"SELECT year('{current_date}') AS year").collect()[0]['year']
print(f"CURRENT YEAR : {current_year}")

# Calculate and Print Day in the Year
day_in_year = spark.sql(f"SELECT dayofyear('{current_date}') AS day_in_year").collect()[0]['day_in_year']
print(f"DAY IN THE YEAR : {day_in_year}")

# Calculate and Print Day in the Month
day_in_month = spark.sql(f"SELECT dayofmonth('{current_date}') AS day_in_month").collect()[0]['day_in_month']
print(f"DAY IN THE MONTH : {day_in_month}")

# Calculate and Print Day in the Week
day_in_week = spark.sql(f"SELECT dayofweek('{current_date}') AS day_in_week").collect()[0]['day_in_week']
print(f"DAY IN THE WEEK : {day_in_week}")

# Calculate and Print Current Month Name
month_name = spark.sql(f"SELECT date_format('{current_date}', 'MMMM') AS month_name").collect()[0]['month_name']
print(f"CURRENT MONTH : {month_name}")

# Print End Message
print("----**** Your Script has executed successfully *****------")

# Stop Spark Session
spark.stop()
```