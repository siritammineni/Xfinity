```java
import java.text.SimpleDateFormat;
import java.util.Date;

public class JB_COMPLEX_SCR {

    public static void main(String[] args) {
        System.out.println("----**** Your Script has started execution *****------");

        // Get current date
        Date currentDate = new Date();

        // Print today's date
        SimpleDateFormat dayFormat = new SimpleDateFormat("dd");
        System.out.println("TODAY'S DATE : " + dayFormat.format(currentDate));

        // Print current month number
        SimpleDateFormat monthNumberFormat = new SimpleDateFormat("MM");
        System.out.println("CURRENT MONTH NUMBER :" + monthNumberFormat.format(currentDate));

        // Print current year
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        System.out.println("CURRENT YEAR :" + yearFormat.format(currentDate));

        // Print day in the year
        SimpleDateFormat dayOfYearFormat = new SimpleDateFormat("D");
        System.out.println("DAY IN THE YEAR : " + dayOfYearFormat.format(currentDate));

        // Print day in the month
        SimpleDateFormat dayOfMonthFormat = new SimpleDateFormat("d");
        System.out.println("DAY IN THE MONTH : " + dayOfMonthFormat.format(currentDate));

        // Print day in the week
        SimpleDateFormat dayOfWeekFormat = new SimpleDateFormat("u");
        System.out.println("DAY IN THE WEEK : " + dayOfWeekFormat.format(currentDate));

        // Print current month name
        SimpleDateFormat monthNameFormat = new SimpleDateFormat("MMMM");
        System.out.println("CURRENT MONTH : " + monthNameFormat.format(currentDate));

        System.out.println("----**** Your Script has executed successfully *****------");
    }
}
```