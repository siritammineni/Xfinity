```java
// Talend Job Script in Java for the given SAP BODS script

import java.util.logging.Logger;

public class JB_SIMPLE_SCR {

    private static final Logger LOGGER = Logger.getLogger(JB_SIMPLE_SCR.class.getName());

    public static void main(String[] args) {
        // Log the start of the script execution
        LOGGER.info("----**** Your Script has started execution *****------");

        // Calculate and log the length of the job name
        String jobName = "JB_SIMPLE_SCR";
        int jobNameLength = jobName.length();
        LOGGER.info("Length of the job name is: " + jobNameLength);

        // Log the successful execution of the script
        LOGGER.info("----**** Your Script has executed successfully *****------");
    }
}
```