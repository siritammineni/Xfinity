```java
// Talend Job Script in Java
import java.text.SimpleDateFormat;
import java.util.Date;

public class JB_MEDIUM_SCR {

    public static void main(String[] args) {
        // Print the start of the script execution
        System.out.println("----**** Your Script has started execution *****------");

        // Get the current system date
        Date currentDate = new Date();

        // Extract and print the day
        SimpleDateFormat dayFormat = new SimpleDateFormat("dd");
        String currentDay = dayFormat.format(currentDate);
        System.out.println("TODAY'S DATE : " + currentDay);

        // Extract and print the month
        SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
        String currentMonth = monthFormat.format(currentDate);
        System.out.println("CURRENT MONTH :" + currentMonth);

        // Extract and print the year
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        String currentYear = yearFormat.format(currentDate);
        System.out.println("CURRENT YEAR :" + currentYear);

        // Print the end of the script execution
        System.out.println("----**** Your Script has executed successfully *****------");
    }
}
```