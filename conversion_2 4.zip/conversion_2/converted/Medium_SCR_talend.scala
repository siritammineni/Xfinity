```scala
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object JB_MEDIUM_SCR {
  def main(args: Array[String]): Unit = {
    // Job Initialization
    println("----**** Your Script has started execution *****------")

    // Print Current Date Information
    val currentDate = LocalDate.now()
    val day = currentDate.format(DateTimeFormatter.ofPattern("dd"))
    val month = currentDate.format(DateTimeFormatter.ofPattern("MM"))
    val year = currentDate.format(DateTimeFormatter.ofPattern("yyyy"))

    println(s"TODAY'S DATE: $day")
    println(s"CURRENT MONTH: $month")
    println(s"CURRENT YEAR: $year")

    // Print Completion Message
    println("----**** Your Script has executed successfully *****------")
  }
}
```