import os
import requests
import json
from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv()

class ResponderEngine:
    def __init__(self, model_config):
        default_config = {
            'provider': 'azure',
            'api_key': os.getenv("GPT_AZURE_KEY"),
            'endpoint': os.getenv("GPT_AZURE_ENDPOINT"),
            'deployment': os.getenv("GPT_AZURE_DEPLOYMENT"),
            'api_version': os.getenv("GPT_AZURE_API_VERSION", "2024-12-01-preview"),
        }
        self.config = model_config if model_config else default_config
        self.provider = self.config.get("provider")

        if self.provider == "azure":
            self.client = AzureOpenAI(
                api_key=self.config["api_key"],
                api_version=self.config["api_version"],
                azure_endpoint=self.config["endpoint"]
            )
        elif self.provider == "huggingface":
            self.api_url = self.config.get("api_url")
            self.headers = {
                "Authorization": f"Bearer {self.config.get('api_key')}",
                "Content-Type": "application/json"
            }
            self.client = None
        else:
            raise ValueError(f"Unsupported provider: {self.provider}")
        print(f" Using provider: {self.provider}")
        

    def get_response(self, prompt: str):
        if self.provider == "azure":
            return self._query_azure(prompt)
        elif self.provider == "huggingface":
            return self._query_huggingface(prompt)
        else:
            raise NotImplementedError(f"Provider '{self.provider}' not supported.")
    def query(self, prompt, system_prompt = ""):
        if self.provider == "azure":
            return self._query_azure(prompt, system_prompt)
        elif self.provider == "huggingface":
            return self._query_huggingface(prompt, system_prompt)
        else:
            raise ValueError(f"Unknown provider: {self.provider}")

    def _query_azure(self, prompt: str, system_prompt=""):
        response = self.client.chat.completions.create(
            model=self.config["deployment"],
            messages=[{"role": "system", "content": system_prompt},
                      {"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=1000
        )
        return response.choices[0].message.content.strip()

    def _query_huggingface(self, prompt: str, system_prompt = ""):
        print("Using Huggingface model....")
        print("Huggingface URL:", self.api_url)
        body = {
            "inputs": f"{system_prompt}\n{prompt}",
            "parameters": {
                "temperature": 0.3,
                "max_new_tokens": 2048
            }
        }
        try:
            response = requests.post(self.api_url, headers=self.headers, json=body)
            response.raise_for_status()
            result = response.json()
            return result[0]["generated_text"].strip()
        except requests.exceptions.RequestException as e:
            return f"Error communicating with Hugging Face API: {str(e)}"
        # headers = {
        #     "Authorization": f"Bearer {self.config['api_key']}",
        #     "Content-Type": "application/json"
        # }
        # full_prompt = system_prompt + "\n\n" + prompt if system_prompt else prompt
        # payload = {  
        #     "inputs": full_prompt,
        #     "parameters": {
        #         "max_new_tokens": 512,
        #         "return_full_text": False
        #     }
        # }
        # response = requests.post(
        #     url=f"https://api-inference.huggingface.co/models/{self.config['model']}",
        #     headers=headers,
        #     json=payload
        # )
        # if response.status_code == 200:
        #     result = response.json()
        #     if isinstance(result, list) and "generated_text" in result[0]:
        #         return result[0]["generated_text"]
        #     return json.dumps(result)  # fallback if structure differs
        # else:
        #     raise Exception(f"Hugging Face API error: {response.status_code} - {response.text}")
        
        
    def run_batched_analysis(self, code, repo_name):
        system_prompt = f"""You are a multi-functional code review assistant. Perform the following analyses for the provided code from {repo_name}:

                            1. **Quality Analysis**: Analyze and provide a brief summary of its quality in terms of structure, readability, and naming.
                                Use no more than 4 bullet points. No improvement suggestions.
                            2. **Bug Detection**: Analyze code and identify any possible bugs, logic errors, or syntax issues.
                                    For each issue:
                                    1. **Specify the line number** where the bug occurs.
                                    2. **Provide the exact code** causing the issue on that line.
                                    3. **Explain the problem** clearly.
                                    4. Suggest a **fixed version of the code** for that specific line.
                                    Ensure that you are providing clear, detailed explanations of why the code is problematic, and offer the correct way to fix it.
                            3. **Optimization Suggestions**: Suggest 3–5 improvements for performance, memory, or security in bullet-point HTML format.
                            4. **Unit Test Suggestions**: Recommend up to 5 essential unit tests using the respective testing framework and keep the point short.

                            Respond in this strict JSON format:
                            {{
                                "quality_analysis": "string",
                                "bug_detection": "string",
                                "optimization_suggestions": "string",
                                "unit_test_suggestions": "string"
                            }}"""

        prompt = f"Code:\n{code}"
        raw_response = self.query(prompt, system_prompt)
    
        try:
            return json.loads(raw_response)
        except json.JSONDecodeError:
            return {
            "quality_analysis": "Could not parse response.",
            "bug_detection": "Could not parse response.",
            "optimization_suggestions": "Could not parse response.",
            "unit_test_suggestions": "Could not parse response."
        }
    
    def run_final_code_generator(self, code, quality, bugs, optimizations):
        system_prompt =  f"""You are a senior software engineer. Create a concise and optimized version of the original code, based on the provided quality issues, bug fixes, and optimizations.
        Limit comments and use clean formatting. Return code as an HTML-formatted code block. If the {code} is HTML then generate the optimized code for this section and return it in an ESCAPED FORMAT,
        so it can be rendered as visible code inside a <pre><code> block in HTML."""
        prompt = f"""
        code: {code}

        --- Reviews ---
        Quality: {quality}
        Bugs: {bugs}
        optimizations: {optimizations}
        return self.query(prompt, system_prompt)"""

        return self.query(prompt, system_prompt)

    def run_report_generation(self, quality, bugs, optimizations, tests, final_code, repo_name):
        system_prompt = f"""You are an HTML report generator. Generate a clean, minimal HTML report for the repo {repo_name} using the following sections: Quality Analysis, Bug Detection, Optimizations, Test Suggestions, Final Code, Summary, and Conclusion.

                        Strict HTML Formatting Rules:
                        - Use <h3> for main sections and <h4> for sub-sections.
                        - Use <ul><li> for bullet points.
                        - Highlight keywords with <strong>.
                        - Format code with <pre><code class='language-{{lang}}'></code></pre>.
                        - DO NOT use Markdown or HTML table tags.
                        - DO NOT invent or skip any section.

                        Ensure that for Bug Detection you mention the line where the error is and explain the issue there.
                        DO NOT give the code in escaped format everytime just give it when the code is in the HTML language
                        Ensure the report is short and structured for easy rendering on a UI.
                        """
        prompt = f"""
                        <h3>Quality Analysis</h3>
                        {quality}

                        <h3>Bug Detection</h3>
                        {bugs}

                        <h3>Optimization Suggestions</h3>
                        {optimizations}

                        <h3>Unit Test Suggestions</h3>
                        {tests}

                        <h3>Final Optimized Code</h3>
                        <pre><code class='language-python'>
                        {final_code}
                        </code></pre>

                        <h3>Summary</h3>
                        <ul>
                        <li><strong>Code Quality:</strong> [Excellent / Good / Needs Improvement]</li>
                        <li><strong>Bugs:</strong> [None / Minor / Major]</li>
                        <li><strong>Optimizations:</strong> [None / Minor / Major]</li>
                        <li><strong>Testing:</strong> [Well Covered / Needs More Tests / No Tests]</li>
                        </ul>

                        <h3>Conclusion</h3>
                        <p>Provide a short recommendation on whether the code is production-ready, needs revisions, or should be refactored.</p>
                        """

        
        return self.query(prompt, system_prompt)
    
    def run_functionality_comparison(self, original_chunks, converted_chunks):
        system_prompt = """You are an expert software code reviewer and functionality comparison analyst.

Your task is to evaluate a converted codebase against a reference (ground truth) implementation and present the findings as a neatly structured HTML report.

---

### Instructions:

1. **Functionality Coverage**
   - List all core functionalities implemented in the reference code.
   - For each functionality, assess the corresponding implementation in the converted code.
   - For each entry, include:
     - **Functionality Name**
     - **Conversion Status** with percentage:
       - ✅ Match (100%)
       - ❌ Missing (0%)
       - ⚠️ Partial (estimate a percentage between 1%–99%)
     - **Detailed Description**:
       - For Partial: Explain which parts are covered and estimate how complete it is.
       - For Missing: What is absent and why it matters?
   - After listing all functionalities, compute the **Overall Functionality Conversion Percentage** by:
     - Averaging the numeric conversion percentages from each functionality entry.
     - Show this clearly below the table.

2. **Code Quality of Converted Code**
   - Evaluate clarity, modularity, maintainability, and best practices.
   - Highlight any issues such as:
     - Hardcoded values
     - Lack of error handling
     - Tightly coupled logic
     - Redundant or duplicate code
     - Poor naming conventions
   - Provide concise yet specific observations.

3. **Enhancements or Drawbacks**
   - List any improvements found in the converted version (e.g., better UI, performance enhancements).
   - Note any **regressions**, **loss of functionality**, or **deviation from original behavior**.

4. **Code Revision**
   - Provide a cleaned-up and improved version of the converted code addressing identified issues.
   - Apply fixes and clean formatting without over-commenting.
   - Present the revised code in an HTML-formatted block:
     - Use: <pre><code> ... </code></pre>

---

### Output Format (Strict HTML Only):
Return a valid and complete <html> document with these sections:
- Title: **Functionality Comparison Report**
- <h3> Functional Comparison Table </h3>
  - Render as an HTML table with columns: **Functionality**, **Conversion Status**, **Details**, **percentage_converted**
  - Use color coding:
    - ✅ in green
    - ❌ in red
    - ⚠️ in orange
  - Include overall conversion percentage below the table
- <h3> Code Quality Assessment </h3>
  - Paragraph or bullet points
- <h3> Enhancements / Suggestions </h3>
  - Unordered list
- <h3> Revised Code </h3>
  - Code block using <pre><code> ... </code></pre>
- Use embedded or inline CSS for neat styling:
  - Consistent font, spacing, table borders
  - Emphasize headings, status colors, and formatting

DO NOT return Markdown or plain text. ONLY valid HTML.
"""

        prompt = f"""
### Reference Code (Ground Truth):
{original_chunks}
### Converted Code:

{converted_chunks}"""
        return self.query(prompt, system_prompt)
    def generate_pseudo_code(self, xml_chunks):
        system_prompt = """
        you are an expert in generating the pseudo code for a BODS script that is exported as an xml file.

        consider the given chunks of an xml input and generate a detailed pseudo code considering all the ETL operations in the xml file. 
"""
        prompt = f"""
        Input xml script: {xml_chunks}
"""
        return self.query(prompt, system_prompt)
    def sql_converter(self, original_chunks, pseudo_code = None):
        if pseudo_code:
          system_prompt = f"""
          You are an expert in Converting BODS script generated in ATL to Talend script that is generated in SQL by considering the pseudocode that is generated from the Bods script that is exported as an xml file
          Consider the given Input BODS script file and pseudocode to convert the script to Talend JOB script in SQL

          ### Instructions:
          1. Read and understand the logic in the provided SAP script.
          2. Identify any data extraction, transformation, and loading (ETL) operations.
          3. Map SAP-specific functions to Talend components (e.g., tFileInputDelimited, tMap, tDBOutput).
          4. Refer the pseudo code generated as a support file to understand the bods script provided.
          4. Generate the Talend Job script in SQL

          ### INPUT code : {original_chunks}
          ### Pseudo code : {pseudo_code}

          ### OUTPUT:
          -Output only the Talend script. Do not explain the conversion.

  """
        
          prompt = f"""
            ###Input SAP code: {original_chunks}
            ###Pseudo Code: {pseudo_code}
  """
        else:
            system_prompt = f"""
          You are an expert in Converting BODS script generated in ATL to Talend script that is generated in SQL.
          Convert the given BODS script to a Talend JOB script in SQL **without relying on any pseudocode**.

          ### Instructions:
          1. Read and understand the logic in the provided SAP script.
          2. Identify any data extraction, transformation, and loading (ETL) operations.
          3. Map SAP-specific functions to Talend components (e.g., tFileInputDelimited, tMap, tDBOutput).
          4. Generate the Talend Job script in SQL.

          ### INPUT code : {original_chunks}

          ### OUTPUT:
          - Output only the Talend script. Do not explain the conversion.
          """
            prompt = f"""
          ###Input SAP code: {original_chunks}
          """
        return self.query(prompt, system_prompt)
    def scala_converter(self, original_chunks, pseudo_code = None):
        if pseudo_code:
          system_prompt = f"""
          You are an expert in Converting BODS script generated in ATL to Talend script that is generated in Scala by considering the pseudocode that is generated from the Bods script that is exported as an xml file
          Consider the given Input BODS script file and pseudocode to convert the script to Talend JOB script in Scala

          ### Instructions:
          1. Read and understand the logic in the provided SAP script.
          2. Identify any data extraction, transformation, and loading (ETL) operations.
          3. Map SAP-specific functions to Talend components (e.g., tFileInputDelimited, tMap, tDBOutput).
          4. Refer the pseudo code generated as a support file to understand the bods script provided.
          4. Generate the Talend Job script in Scala

          ### INPUT code : {original_chunks}
          ### Pseudo code : {pseudo_code}

          ### OUTPUT:
          -Output only the Talend script. Do not explain the conversion.

  """
        
          prompt = f"""
            ###Input SAP code: {original_chunks}
            ###Pseudo Code: {pseudo_code}
  """
        else:
            system_prompt = f"""
          You are an expert in Converting BODS script generated in ATL to Talend script that is generated in Scala.
          Convert the given BODS script to a Talend JOB script in Scala **without relying on any pseudocode**.

          ### Instructions:
          1. Read and understand the logic in the provided SAP script.
          2. Identify any data extraction, transformation, and loading (ETL) operations.
          3. Map SAP-specific functions to Talend components (e.g., tFileInputDelimited, tMap, tDBOutput).
          4. Generate the Talend Job script in Scala.

          ### INPUT code : {original_chunks}

          ### OUTPUT:
          - Output only the Talend script. Do not explain the conversion.
          """
            prompt = f"""
          ###Input SAP code: {original_chunks}
          """
        return self.query(prompt, system_prompt)
    def pyspark_converter(self, original_chunks, pseudo_code=None):
        if pseudo_code:
          system_prompt = f"""
          You are an expert in Converting BODS script generated in ATL to Talend script that is generated in Pyspark by considering the pseudocode that is generated from the Bods script that is exported as an xml file
          Consider the given Input BODS script file and pseudocode to convert the script to Talend JOB script in Pyspark

          ### Instructions:
          1. Read and understand the logic in the provided SAP script.
          2. Identify any data extraction, transformation, and loading (ETL) operations.
          3. Map SAP-specific functions to Talend components (e.g., tFileInputDelimited, tMap, tDBOutput).
          4. Refer the pseudo code generated as a support file to understand the bods script provided.
          4. Generate the Talend Job script in Pyspark

          ### INPUT code : {original_chunks}
          ### Pseudo code : {pseudo_code}

          ### OUTPUT:
          -Output only the Talend script. Do not explain the conversion.

  """
        
          prompt = f"""
            ###Input SAP code: {original_chunks}
            ###Pseudo Code: {pseudo_code}
  """
        else:
            system_prompt = f"""
          You are an expert in Converting BODS script generated in ATL to Talend script that is generated in Pyspark.
          Convert the given BODS script to a Talend JOB script in Pyspark **without relying on any pseudocode**.

          ### Instructions:
          1. Read and understand the logic in the provided SAP script.
          2. Identify any data extraction, transformation, and loading (ETL) operations.
          3. Map SAP-specific functions to Talend components (e.g., tFileInputDelimited, tMap, tDBOutput).
          4. Generate the Talend Job script in Pyspark.

          ### INPUT code : {original_chunks}

          ### OUTPUT:
          - Output only the Talend script. Do not explain the conversion.
          """
            prompt = f"""
          ###Input SAP code: {original_chunks}
          """
            
        return self.query(prompt, system_prompt)
        
    def java_converter(self, original_chunks, pseudo_code=None):
      if pseudo_code:
          system_prompt = f"""
          You are an expert in Converting BODS script generated in ATL to Talend script that is generated in JAVA by considering the pseudocode that is generated from the Bods script that is exported as an xml file.
          Consider the given Input BODS script and pseudocode to convert the script to a Talend JOB script in JAVA.

          ### Instructions:
          1. Read and understand the logic in the provided SAP script.
          2. Identify any data extraction, transformation, and loading (ETL) operations.
          3. Map SAP-specific functions to Talend components (e.g., tFileInputDelimited, tMap, tDBOutput).
          4. Refer to the pseudo code generated from the XML as support for understanding the BODS script.
          5. Generate the Talend Job script in JAVA.

          ### INPUT code : {original_chunks}
          ### Pseudo code : {pseudo_code}

          ### OUTPUT:
          - Output only the Talend script. Do not explain the conversion.
          """
          prompt = f"""
          ###Input SAP code: {original_chunks}
          ###Pseudo Code: {pseudo_code}
          """
      else:
          system_prompt = f"""
          You are an expert in Converting BODS script generated in ATL to Talend script that is generated in JAVA.
          Convert the given BODS script to a Talend JOB script in JAVA **without relying on any pseudocode**.

          ### Instructions:
          1. Read and understand the logic in the provided SAP script.
          2. Identify any data extraction, transformation, and loading (ETL) operations.
          3. Map SAP-specific functions to Talend components (e.g., tFileInputDelimited, tMap, tDBOutput).
          4. Generate the Talend Job script in JAVA.

          ### INPUT code : {original_chunks}

          ### OUTPUT:
          - Output only the Talend script. Do not explain the conversion.
          """
          prompt = f"""
          ###Input SAP code: {original_chunks}
          """

      return self.query(prompt, system_prompt)


