from langgraph.graph import StateGraph, END
from responder_engine import ResponderEngine
from typing import TypedDict
import time

def agent_graph(engine):
    class ReviewState(TypedDict):
        repo: str
        code: str
        quality_analysis: str
        bug_report: str
        optimizations: str
        unittest_report: str
        final_code: str
        final_report: str

    graph = StateGraph(ReviewState)

    def batched_review_agent(state):
        code = state["code"]
        repo = state["repo"]
        print("Running batched review agent...")
        start = time.time()
        analysis = engine.run_batched_analysis(code, repo)
        end = time.time()
        exec = end - start
        print(f"Batched review took: {exec:.2f} seconds")

        return {
                "quality_analysis": analysis["quality_analysis"],
                "bug_report": analysis["bug_detection"],
                "optimizations": analysis["optimization_suggestions"],
                "unittest_report": analysis["unit_test_suggestions"],
            }

    def final_code_generation_agent(state):
        print("Entered code generator")
        start = time.time()
        final_code = engine.run_final_code_generator(
                code=state["code"],
                quality=state["quality_analysis"],
                bugs=state["bug_report"],
                optimizations=state["optimizations"],
            )
        end = time.time()
        exec = end - start
        print("code generation completed")
        print(f"code generation took:{exec}seconds")
        return {"final_code": final_code}



    def report_generation_agent(state):
        start = time.time()
        report = engine.run_report_generation(
            quality=state["quality_analysis"],
                bugs=state["bug_report"],
                optimizations=state["optimizations"],
                tests=state["unittest_report"],
                final_code= state["final_code"],
                repo_name=state["repo"]
            )
        end = time.time()
        exec = end - start
        print(f"report generation took:{exec}seconds")
        return {"final_report": report}


    graph.add_node("BatchedReview", batched_review_agent)
    graph.add_node("ReportGeneration", report_generation_agent)
    graph.add_node("FinalCodeGeneration", final_code_generation_agent)

    graph.set_entry_point("BatchedReview")
    graph.add_edge("BatchedReview", "FinalCodeGeneration")
    graph.add_edge("FinalCodeGeneration", "ReportGeneration")
    graph.add_edge("ReportGeneration", END)

    app = graph.compile()
    return app

