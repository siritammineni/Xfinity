```java
// Talend Job Script in Java

import java.text.SimpleDateFormat;
import java.util.Date;

public class JB_MEDIUM_SCR {

    public static void main(String[] args) {
        try {
            // Print start message
            System.out.println("----**** Your Script has started execution *****------");

            // Get current date
            Date currentDate = new Date();
            SimpleDateFormat dayFormat = new SimpleDateFormat("dd");
            SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
            SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");

            // Print today's date
            System.out.println("TODAY'S DATE : " + dayFormat.format(currentDate));

            // Print current month
            System.out.println("CURRENT MONTH : " + monthFormat.format(currentDate));

            // Print current year
            System.out.println("CURRENT YEAR : " + yearFormat.format(currentDate));

            // Print end message
            System.out.println("----**** Your Script has executed successfully *****------");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
```