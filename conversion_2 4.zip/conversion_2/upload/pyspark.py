# Import necessary libraries
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("Sample PySpark Application") \
    .getOrCreate()

# Read data from a CSV file into a DataFrame
input_file_path = "path/to/input.csv"
df = spark.read.csv(input_file_path, header=True, inferSchema=True)

# Show the initial DataFrame
print("Initial DataFrame:")
df.show()

# Perform some transformations
# Example: Filter rows where 'age' is greater than 30
filtered_df = df.filter(col("age") > 30)

# Example: Select specific columns
selected_df = filtered_df.select("name", "age", "salary")

# Example: Calculate average salary
average_salary = selected_df.agg(avg("salary")).collect()[0][0]
print(f"Average Salary: {average_salary}")

# Show transformed DataFrame
print("Transformed DataFrame:")
selected_df.show()

# Write the transformed DataFrame to a new CSV file
output_file_path = "path/to/output.csv"
selected_df.write.csv(output_file_path, header=True, mode="overwrite")

# Stop the SparkSession
spark.stop()
