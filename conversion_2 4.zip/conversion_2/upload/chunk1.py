import os
import git
import ast
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# Load embedding model
model = SentenceTransformer("BAAI/bge-base-en-v1.5")

# Clone repository
def clone_repo(repo_url, clone_dir="cloned_repo"):
    if os.path.exists(clone_dir):
        print(f"Repository already cloned at {clone_dir}.")
    else:
        print(f"Cloning {repo_url}...")
        git.Repo.clone_from(repo_url, clone_dir)
    return clone_dir


# Extract function-based & structural chunks for Python
def extract_python_chunks(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        code = f.read()

    tree = ast.parse(code)
    chunks = []
    imports = []
    loose_code = []

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            chunks.append(ast.get_source_segment(code, node))
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            imports.append(ast.get_source_segment(code, node))
        else:
            loose_code.append(ast.get_source_segment(code, node))

    # Store separate chunks
    if imports:
        chunks.insert(0, "\n".join(imports))  
    if loose_code:
        chunks.append("\n".join(loose_code))

    return chunks

# Process repository
def process_repo(repo_path):
    code_chunks = []
    for root, _, files in os.walk(repo_path):
        for file in files:
            file_path = os.path.join(root, file)
            if file.endswith(".py"):  # Add more conditions for other languages
                print(f"Processing {file_path}...")
                chunks = extract_python_chunks(file_path)
                code_chunks.extend(chunks)
    for i, chunk in enumerate(code_chunks):
        print(f"Chunk {i+1}:\n{chunk}\n")
    
    return code_chunks


# Convert chunks to embeddings and store in FAISS
def store_embeddings_in_faiss(chunks, faiss_index_file="code_index.faiss"):
    embeddings = np.array([model.encode(chunk) for chunk in chunks])
    dimension = embeddings.shape[1]

    # Initialize FAISS index
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)

    # Save FAISS index
    faiss.write_index(index, faiss_index_file)
    print(f"FAISS index saved as {faiss_index_file}")

# Main function
def main(repo_url):
    repo_path = clone_repo(repo_url)
    chunks = process_repo(repo_path)
    store_embeddings_in_faiss(chunks)

# Example usage
repo_url = "https://github.com/himajanttdata/Xfinity-Chat.git"
main(repo_url)