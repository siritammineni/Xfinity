```java
// Talend Job Script in Java

package local_project.JB_SIMPLE_SCR;

import routines.*;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import routines.system.*;
import routines.system.api.*;

public class JB_SIMPLE_SCR implements TalendJob {
    private static Logger log = Logger.getLogger(JB_SIMPLE_SCR.class);
    private static final String jobName = "JB_SIMPLE_SCR";

    public static void main(String[] args) {
        JB_SIMPLE_SCR job = new JB_SIMPLE_SCR();
        job.runJob(args);
    }

    public void runJob(String[] args) {
        try {
            System.out.println("----**** Your Script has started execution *****------");

            // Print the length of the job name
            System.out.println("Length of the job name is: " + jobName.length());

            System.out.println("----**** Your Script has executed successfully *****------");
        } catch (Exception e) {
            log.error("An error occurred during job execution: " + e.getMessage());
        }
    }
}
```