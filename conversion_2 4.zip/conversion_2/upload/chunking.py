import ast
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

file_path = r"C:\Users\338574\Documents\Capstone-final\agent.py"
def extract_functions(file_path):
    with open(file_path, "r", encoding = "utf-8") as f:
        tree = ast.parse(f.read())
    
    functions = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            functions.append(ast.unparse(node))
    return functions

chunks = extract_functions(file_path)

for i, chunk in enumerate(chunks):
    print(f"Chunk {i+1}:\n{chunk}\n")
    
model = SentenceTransformer("BAAI/bge-base-en-v1.5")
embeddings = model.encode(chunks, convert_to_tensor = False)
print(f"Generated {len(embeddings)} embeddings.")

embedding_dim = embeddings.shape[1]

index = faiss.IndexFlatL2(embedding_dim)
embeddings = np.array(embeddings).astype(np.float32)

index.add(embeddings)
faiss.write_index(index, "faiss_embeddings.index")

print("Embeddings are stored successfully in faiss index.")

