from langgraph.graph import StateGraph, END, START
from hf import ResponderEngine
from responder_engine import ResponderEngine
from typing import TypedDict
import time

def create_conversion_graph(engine):

    class ConvertState(TypedDict):
        original_chunks : str
        xml_chunks : str
        target : str
        pseudo_code: str
        conversion : str
        responder: str

    graph = StateGraph(ConvertState)

    def initial_router(state):
        xml_chunks = state.get("xml_chunks", "")
        if xml_chunks:  # Check if XML is provided and not empty
            return "Pseudocode"
        else:
            return router_node(state)  # Route directly to correct converter

    def pseudo_code_agent(state):
        xml_chunks = state["xml_chunks"]
        print("generating pseudo code..")
        pseudo_code = engine.generate_pseudo_code(xml_chunks)
        return{
            "xml_chunks" : xml_chunks,
            "pseudo_code": pseudo_code
        }

    def java_converter(state):
        original_chunks = state["original_chunks"]
        pseudo_code = state.get("pseudo_code")
        print("Entered Java conversion agent ...")
        if pseudo_code:
            conversion = engine.java_converter(original_chunks, pseudo_code)
        else:
            conversion = engine.java_converter(original_chunks)
        return{
            "original_chunks": original_chunks,
            "pseudo_code": pseudo_code if pseudo_code else "",
            "conversion" : conversion
            }

    def pyspark_converter(state):
        original_chunks = state["original_chunks"]
        pseudo_code = state.get("pseudo_code")
        print("Entered Pyspark conversion agent ...")
        if pseudo_code:
            conversion = engine.pyspark_converter(original_chunks, pseudo_code)
        else:
            conversion = engine.pyspark_converter(original_chunks)
        return{
            "original_chunks": original_chunks,
            "pseudo_code": pseudo_code if pseudo_code else "",
            "conversion" : conversion
            }

    def scala_converter(state):
        original_chunks = state["original_chunks"]
        pseudo_code = state.get("pseudo_code")
        print("Entered Scala conversion agent ...")
        if pseudo_code:
            conversion = engine.scala_converter(original_chunks, pseudo_code)
        else:
            conversion = engine.scala_converter(original_chunks)
        return{
            "original_chunks": original_chunks,
            "pseudo_code": pseudo_code if pseudo_code else "",
            "conversion" : conversion
            }
    def sql_converter(state):
        original_chunks = state["original_chunks"]
        pseudo_code = state.get("pseudo_code")
        print("Entered SQL conversion agent ...")
        if pseudo_code:
            conversion = engine.sql_converter(original_chunks, pseudo_code)
        else:
            conversion = engine.sql_converter(original_chunks)
        return{
            "original_chunks": original_chunks,
            "pseudo_code": pseudo_code if pseudo_code else "",
            "conversion" : conversion
            }

    def router_node(state):
        target = state["target"]
        if target.lower() == 'java':
            return 'java_converter'
        elif target.lower() == 'pyspark':
            return 'pyspark_converter'
        elif target.lower() == 'scala':
            return 'scala_converter'
        else:
            return 'sql_converter'


    # def conversion_agent(state):
    #     original_chunks = state["original_chunks"]
    #     pseudo_code = state["pseudo_code"]
    #     target = state["target"]
    #     print("Entered conversion agent ...")
    #     conversion = engine.converter(original_chunks, pseudo_code, target)
    #     return{
    #         "original_chunks": original_chunks,
    #         "pseudo_code": pseudo_code,
    #         "target":target,
    #         "conversion" : conversion
    #         }

    graph.add_node("initial_router", lambda x: x)  # Identity function, no-op

    graph.add_node("Pseudocode", pseudo_code_agent)
    graph.add_node("java_converter", java_converter)
    graph.add_node("pyspark_converter", pyspark_converter)
    graph.add_node("scala_converter", scala_converter)
    graph.add_node("sql_converter", sql_converter)
    # graph.add_node("Conversion",conversion_agent)

    # graph.set_entry_point("Pseudocode")
    # graph.add_edge("Pseudocode", "Conversion")
    # graph.add_edge("Conversion", END)
    # Set new entry point
    graph.set_entry_point("initial_router")

    # Connect routing logic
    graph.add_conditional_edges("initial_router", initial_router)

    # graph.set_entry_point("Pseudocode")
    # graph.add_edge(START, "Pseudocode")
    graph.add_conditional_edges("Pseudocode", router_node)
    graph.add_edge("java_converter", END)
    graph.add_edge("pyspark_converter", END)
    graph.add_edge("sql_converter", END)
    graph.add_edge("scala_converter", END)

    # graph.set_finish_point(END)


    app = graph.compile()
    return app

    # # Visualize your graph
    # from IPython.display import Image, display
    # png = app.get_graph().draw_mermaid_png()

    # display(Image(png))
