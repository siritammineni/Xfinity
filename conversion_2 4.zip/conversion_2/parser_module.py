from langchain.schema import AIMessage  # or whatever your actual import is

def parse(ai_message_str : str) -> str:
    """Parse the AI message and strip code block markers (```lang ... ```)"""
    cleaned_response = ai_message_str.strip()

    # Remove code block markers like ```java, ```python, etc.
    if cleaned_response.startswith("```"):
        # Find the first newline after the language identifier
        first_newline_index = cleaned_response.find("\n")
        if first_newline_index != -1:
            cleaned_response = cleaned_response[first_newline_index + 1:]

    if cleaned_response.endswith("```"):
        cleaned_response = cleaned_response[:-3]

    cleaned_response = cleaned_response.strip()
    
    return cleaned_response
